package com.excelr.Project.ProductManagementSystem.ExceptionHandler;

public class ProductExpiredException extends Exception {
    public ProductExpiredException(String message) {
        super(message);
    }
}

